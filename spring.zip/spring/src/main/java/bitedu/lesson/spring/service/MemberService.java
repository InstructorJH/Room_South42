package bitedu.lesson.spring.service;

import java.sql.SQLException;
import java.util.ArrayList;

import bitedu.lesson.spring.dao.MemberDAO;
import bitedu.lesson.spring.vo.MemberVO;

public class MemberService {
	
	// 비즈니스 로직 : 로그인
	public MemberVO isMember(String id, String pwd) {
		boolean flag = false; //memberVO로 리턴타입 수정
		MemberVO member = null;
		MemberDAO dao = new MemberDAO();
		try {
			member = dao.selectMember(id,pwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}
	
	public ArrayList<MemberVO> findAll(){
		ArrayList<MemberVO> list = null;
		MemberDAO dao = new MemberDAO();
		try {
			list = dao.selectAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public MemberVO find(String id) {
		MemberVO member = null;
		MemberDAO dao = new MemberDAO();
		try {
			member = dao.select(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}
	
	public boolean regist(MemberVO member) {
		boolean flag = false;
		MemberDAO dao = new MemberDAO();
		try {
			flag = dao.insert(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean modify(MemberVO member) {
		boolean flag = false;
		MemberDAO dao = new MemberDAO();
		try {
			flag = dao.update(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean remove(String id) {
		boolean flag = false;
		MemberDAO dao = new MemberDAO();
		try {
			flag = dao.delete(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}








