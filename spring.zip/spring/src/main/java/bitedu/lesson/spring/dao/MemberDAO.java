package bitedu.lesson.spring.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import bitedu.lesson.spring.utils.ConnectionManager;
import bitedu.lesson.spring.vo.MemberVO;

public class MemberDAO {
	public ArrayList<MemberVO> selectAll() throws SQLException{
		ArrayList<MemberVO> list = null;
		list = new ArrayList<MemberVO>();
		//database query
		Connection con = ConnectionManager.getConnection();
		if(con!=null) { //test용이어서 다음번 DAO작성때에는 작성하지 않아도 된다.
			//System.out.println(con);
			//쿼리 전송
			String sql = "select * from member";
			Statement stmt = con.createStatement();
			//전송 결과 받아서
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				//vo로 수집해서
				String id = rs.getString(1);//컬럼의 인덱스 또는
				String pwd = rs.getString("pwd"); //컬럼의 이름 가능
				String name = rs.getString(3);
				String email = rs.getString(4);
				Timestamp registDate = rs.getTimestamp(5);
				MemberVO vo = new MemberVO(id, pwd, name, email, registDate);
				//list에 저장
				list.add(vo);
			}
			
		} else {
			System.out.println("fails");
		}
		
		ConnectionManager.closeConnection(null, null, con);
		
		return list;
	}
	
	public MemberVO select(String id) throws SQLException {
		MemberVO member = null;
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from member where id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			//vo로 수집해서
			String pwd = rs.getString("pwd"); //컬럼의 이름 가능
			String name = rs.getString(3);
			String email = rs.getString(4);
			Timestamp registDate = rs.getTimestamp(5);
			member = new MemberVO(id, pwd, name, email, registDate);
		}
		return member;
	}
	
	public boolean insert(MemberVO member) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into member values (?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, member.getId());
		pstmt.setString(2, member.getPwd());
		pstmt.setString(3, member.getName());
		pstmt.setString(4, member.getEmail());
		pstmt.setTimestamp(5, member.getRegistDate());
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}
	
	public boolean update(MemberVO member) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "update member set pwd = ?, name=?, email=? where id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, member.getPwd());
		pstmt.setString(2, member.getName());
		pstmt.setString(3, member.getEmail());
		pstmt.setString(4, member.getId());
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}
	
	public boolean delete(String id) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "delete from member where id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, id);
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}

	//결과페이지에서 많은 정보를 요청하므로 member정보를 리턴
	public MemberVO selectMember(String id, String pwd) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		//DB에 해당 id,pwd를 가진 멤버 확인하는 코드 작성
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from member where id=? and pwd=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pwd);
		ResultSet rs = pstmt.executeQuery();
		MemberVO member = null;
		while(rs.next()) {
			String userid = rs.getString(1);
			String userPwd = rs.getString(2);
			String name = rs.getString(3);
			String email = rs.getString(4);
			Timestamp rd = rs.getTimestamp(5);
			member = new MemberVO(userid, userPwd, name, email, rd);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		if(member!=null) {
			flag = true;
		}
		return member;
	}
}







