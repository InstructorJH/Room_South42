package bitedu.lesson.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller("memberController")
public class MemberController {

	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView basic() {
		ModelAndView mav = new ModelAndView();
		String url = "./login/home";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/viewLoginForm",method = RequestMethod.GET)
	public ModelAndView viewLogin() {
		ModelAndView mav = new ModelAndView();
		String url = "./login/login";
		mav.setViewName(url);
		return mav;
	}
	
}
