package bitedu.lesson.spring.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bitedu.lesson.spring.service.MemberService;
import bitedu.lesson.spring.vo.MemberVO;

public class MemberServlet extends HttpServlet {
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("init");
	}
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("destroy");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println("hello");
		//System.out.println("get method");
		this.doPost(req, resp);
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		String cmd = req.getParameter("cmd");
		String url = "./memberController?cmd=readAll";
		if(cmd==null) {
			cmd="home";
			System.out.println("cmd");
		}
		if(cmd.equals("viewRegistForm")) {
			url = "./member/regist.jsp";
		} else if(cmd.equals("regist")) {
			System.out.println("regist request");
			//회원데이터 수집.
			String id = req.getParameter("id");
			String pwd = req.getParameter("pwd");
			String email = req.getParameter("email");
			String name = req.getParameter("name");
			Timestamp now = new Timestamp(System.currentTimeMillis());
			MemberVO member = new MemberVO(id, pwd, name, email, now);
			// 서비스 요청(DB저장)
			MemberService service = new MemberService();
			boolean flag = service.regist(member);
			// list이동 (기본 url사용)
			
		} else if(cmd.equals("remove")) {
			String id = req.getParameter("id");
			//서비스요청(DB에서 삭제)
			MemberService service = new MemberService();
			boolean flag = service.remove(id);
			//list로 이동 (기본값 이용하여 이동)
		} else if(cmd.equals("modify")) {
			//아래 update에서 구현했음
		} else if(cmd.equals("readAll")) {
			//모든 회원정보를 DB에서 가져와서 리스트 페이지에 전달해야함. 
			MemberService service = new MemberService();
			ArrayList<MemberVO> list = service.findAll();
			req.setAttribute("list", list);
			url = "./member/list.jsp";
		} else if(cmd.equals("search")) {
			String id = req.getParameter("id");
			//서비스요청(DB에서 조회)
			MemberService service = new MemberService();
			MemberVO member = service.find(id);
			req.setAttribute("member", member);
			url = "./member/detail.jsp";
		} else if(cmd.equals("viewUpdateForm")) {
			String id = req.getParameter("id");
			//서비스요청(DB에서 조회)
			MemberService service = new MemberService();
			MemberVO member = service.find(id);
			req.setAttribute("member", member);
			url = "./member/update.jsp";
		} else if(cmd.equals("update")) {
			String id = req.getParameter("id");
			//업데이트 자료 수집
			String pwd = req.getParameter("pwd");
			String email = req.getParameter("email");
			String name = req.getParameter("name");
			MemberVO vo =  new MemberVO(id, pwd, name, email, null);
			//서비스요청(DB 번경저장)
			MemberService service = new MemberService();
			boolean flag = service.modify(vo);
			//list이동(기본 url 이용)
		} else if(cmd.equals("viewLoginForm")) {
			url = "./login/login.jsp";
		} else if(cmd.equals("login")) {
			MemberService service = new MemberService();
			String id = req.getParameter("id");
			String pwd = req.getParameter("pwd");
			MemberVO member = service.isMember(id, pwd);
			if(member!= null) {
				HttpSession session = req.getSession();
				session.setAttribute("member", member);
				url = "./login/home.jsp";
			} else {
				url = "./login/login.jsp";
			}
		} else if(cmd.equals("home")) {
			url = "./login/home.jsp";
		} else if(cmd.equals("logout")) {
			HttpSession session = req.getSession();
			session.invalidate();
			url = "./login/home.jsp";
		}
		
		
		RequestDispatcher rd = req.getRequestDispatcher(url);
		rd.forward(req, resp);
	}
	
}




