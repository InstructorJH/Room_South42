package bitedu.lesson.spring.controller;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import bitedu.lesson.spring.service.MemberService;
import bitedu.lesson.spring.vo.MemberVO;

@Controller("memberController")
public class MemberController {

	@Autowired
	private MemberService service;
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView basic() {
		ModelAndView mav = new ModelAndView();
		String url = "./login/home";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/viewLoginForm",method = RequestMethod.GET)
	public ModelAndView viewLogin() {
		ModelAndView mav = new ModelAndView();
		String url = "./login/login";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public ModelAndView login(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String url = "./login/login";
		String id = req.getParameter("id");
		String pwd = req.getParameter("pwd");
		MemberVO member = service.isMember(id, pwd);
		if(member!= null) {
			HttpSession session = req.getSession();
			session.setAttribute("member", member);
			url = "./login/home";
		}
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String url = "./login/home";
		HttpSession session = req.getSession();
		session.invalidate();
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/readAll", method=RequestMethod.GET)
	public ModelAndView list(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		
		ArrayList<MemberVO> list = service.findAll();
		req.setAttribute("list", list);
		
		String url = "./member/list";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/viewRegistForm", method=RequestMethod.GET)
	public ModelAndView viewRegist() {
		ModelAndView mav = new ModelAndView();
		String url = "./member/regist";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/regist", method=RequestMethod.POST)
	public ModelAndView regist(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		try {
			req.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id = req.getParameter("id");
		String pwd = req.getParameter("pwd");
		String email = req.getParameter("email");
		String name = req.getParameter("name");
		Timestamp now = new Timestamp(System.currentTimeMillis());
		MemberVO member = new MemberVO(id, pwd, name, email, now);
		// 서비스 요청(DB저장)
		boolean flag = service.regist(member);
		
		
		String url = "redirect:./readAll";
		mav.setViewName(url);
		return mav;
	}
	
}
