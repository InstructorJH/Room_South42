package bitedu.lesson.simple.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.lesson.simple.dao.BoardDAO;
import bitedu.lesson.simple.vo.BoardVO;

@Service("boardService")
public class BoardService {
	
	@Autowired
	private BoardDAO boardDAO;
	
	public ArrayList<BoardVO> getBoardList(){
		ArrayList<BoardVO> list = null;
		try {
			list = boardDAO.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
}
