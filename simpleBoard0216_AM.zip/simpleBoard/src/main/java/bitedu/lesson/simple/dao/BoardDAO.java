package bitedu.lesson.simple.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import bitedu.lesson.simple.utils.ConnectionManager;
import bitedu.lesson.simple.vo.BoardVO;

@Repository
public class BoardDAO {
	public ArrayList<BoardVO> findAll() throws SQLException{
		ArrayList<BoardVO> list = null;
		list = new ArrayList<BoardVO>();
		Connection con = ConnectionManager.getConnection();
		//System.out.println(con);
		String sql = "select * from simple_board";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		BoardVO board = null;
		while(rs.next()) {
			int seq = rs.getInt(1);
			String title = rs.getString(2);
			String content = rs.getString(3);
			String writer = rs.getString(4);
			int readCount = rs.getInt(5);
			Timestamp createDate = rs.getTimestamp(6);
			String attatchImg = rs.getString(7);
			String attatchData = rs.getString(8);
			board = new BoardVO(seq, title, content, writer, readCount, createDate, attatchImg, attatchData);
			list.add(board);
		}
		ConnectionManager.closeConnection(rs, stmt, con);
		return list;
	}
}
