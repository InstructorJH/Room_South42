package bitedu.lesson.simple.dao;

import java.sql.SQLException; //crtl+shift+O
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.lesson.simple.vo.BoardVO;
import bitedu.lesson.simple.vo.MemberVO;

@Repository("boardDAO")
public class BoardDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	public List<BoardVO> findAll() throws SQLException{
		List<BoardVO> list = null;
		list = sqlSession.selectList("mapper.board.selectBoardList");
		
		return list;
	}

	public boolean insertBoard(BoardVO board) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.insert("mapper.board.insertBoard", board);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public boolean deleteItem(int seq) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.delete("mapper.board.deleteBoard", seq);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	public boolean updateCount(int seq) throws SQLException {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateCounter", seq);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	public BoardVO selectItem(int seq) throws SQLException {
		// TODO Auto-generated method stub
		BoardVO board = null;
		board = sqlSession.selectOne("mapper.board.findBoard",seq);
		return board;
	}
	
	public boolean selectMember(String id) throws SQLException {
		boolean flag = false;
		MemberVO vo = sqlSession.selectOne("mapper.member.checkMember",id);
		if(vo!=null) {
			flag = true;
		}
		return flag;
	}

	public boolean updateItem(BoardVO board) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateBoard", board);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
}




