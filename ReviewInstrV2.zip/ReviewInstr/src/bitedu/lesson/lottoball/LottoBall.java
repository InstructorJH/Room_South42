package bitedu.lesson.lottoball;

public class LottoBall {
	private int number;
	private boolean isSelected;
	
//	public LottoBall(int number, boolean isSelected) {
//		//super();
//		this.number = number;
//		this.isSelected = isSelected;
//	}
	
	public LottoBall(int number) {
		//super();
		this.number = number;
	}

	public int getNumber() {
		return number;
	}
	
//	public void setNumber(int number) {
//		this.number = number;
//	}
	
	public boolean isSelected() {
		return isSelected;
	}
	
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.valueOf(number);
	}
	
}
