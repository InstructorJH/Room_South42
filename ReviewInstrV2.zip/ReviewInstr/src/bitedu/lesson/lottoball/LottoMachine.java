package bitedu.lesson.lottoball;

import java.util.Random;

public class LottoMachine {
	
	private LottoBall[] balls;
	
	//6개의 공을 한꺼번에 추출하는 메소드
	public void selectBalls() {
		for(int i=0;i<6;i++) {
			LottoBall ball = this.selectBall();
			System.out.println(ball.getNumber()+" 추출되었습니다.");
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//하나씩 뽑는 메소드 (중복처리하여 뽑은 공을 리턴)
	private LottoBall selectBall() {
		LottoBall ball = null;
		// 공을 뽑는 로직 (랜덤으로 볼을 선택)
		Random r = new Random();
		while(true) {
			int index = r.nextInt(balls.length);
			ball = balls[index];
			//중복검사
			if(!ball.isSelected()) {
				ball.setSelected(true); // 뽑힌 공임을 알려주는 코드
				break;
			} 
			// 필요없으나 확인용으로 코딩 ////////////////////////
			else {
				System.out.println("중복 "+balls[index]);
			}
			/////////////////////////////////////////////
		}
		return ball;
	}
	
	public void setBalls(LottoBall[] balls) {
		this.balls = balls;
	}
}
