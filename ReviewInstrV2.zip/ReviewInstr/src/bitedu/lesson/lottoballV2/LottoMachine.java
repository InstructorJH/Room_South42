package bitedu.lesson.lottoballV2;

import java.util.ArrayList;
import java.util.Random;

public class LottoMachine {
	
	//삭제가능한 버전
	private ArrayList<LottoBall> balls;
	
	//6개의 공을 한꺼번에 추출하는 메소드
	public void selectBalls() {
		for(int i=0;i<6;i++) {
			LottoBall ball = this.selectBall();
			System.out.println(ball.getNumber()+" 추출되었습니다.");
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//하나씩 뽑는 메소드 
	private LottoBall selectBall() {
		LottoBall ball = null;
		// 공을 뽑는 로직 (랜덤으로 볼을 선택)
		Random r = new Random();

		int index = r.nextInt(balls.size());
		ball = balls.remove(index);

		return ball;
	}
	
	public void setBalls(ArrayList<LottoBall> balls) {
		this.balls = balls;
	}
}

