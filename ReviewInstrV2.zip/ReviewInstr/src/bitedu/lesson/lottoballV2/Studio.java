package bitedu.lesson.lottoballV2;

import java.util.ArrayList;

public class Studio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Studio sbs = new Studio();
		sbs.onAir();
	}
	
	public void onAir() {
		System.out.println("방송 준비를 시작합니다.");
		ArrayList<LottoBall> balls = this.makeBall();
		System.out.println("로또추첨 최신 기계를 준비합니다.");
		LottoMachine machine = new LottoMachine();
		machine.setBalls(balls);
		System.out.println("지금부터 제XXX회 로또 추첨을 시작합니다.");
		machine.selectBalls();
		System.out.println("이것으로 로또 추첨 방송을 마치겠습니다.\n 감사합니다!");
	}
	
		
	private ArrayList<LottoBall> makeBall() {
		ArrayList<LottoBall> balls = null;
		balls = new ArrayList<LottoBall>();
		for(int i=0;i<45;i++) {
			balls.add(new LottoBall(i+1));
		}
		return balls;
	}

}
