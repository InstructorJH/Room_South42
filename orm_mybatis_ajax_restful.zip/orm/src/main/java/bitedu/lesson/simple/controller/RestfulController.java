package bitedu.lesson.simple.controller;

import java.sql.Timestamp;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import bitedu.lesson.simple.service.BoardService;
import bitedu.lesson.simple.vo.BoardVO;

@RestController("restfulController")
public class RestfulController {
	
	@Autowired
	private BoardService boardService;
	
	
	@RequestMapping(value="/{seq}", method = RequestMethod.GET)
	public BoardVO find(@PathVariable int seq) {
		System.out.println("seq "+seq);
		BoardVO board = boardService.findItem(seq);
		return board;
	}
	
	@RequestMapping(value="/{seq}", method = RequestMethod.DELETE)
	public boolean remove(@PathVariable int seq) {
		System.out.println("remove seq "+seq);
		boolean flag = false;//boardService.removeItem(seq);
		return flag;
	}
	
	@RequestMapping(value=" ", method = RequestMethod.POST)
	public boolean regist(@RequestBody BoardVO board) {
		System.out.println(board);
		board.setCreateDate(new Timestamp(System.currentTimeMillis()));
		boolean flag = boardService.saveItem(board);
		return flag;
	}
	
	@RequestMapping(value="/{seq}", method = RequestMethod.PUT)
	public boolean update(@RequestBody BoardVO board,@PathVariable int seq) {
		System.out.println(board);
		System.out.println(seq);
		board.setSeq(seq);
		boolean flag = boardService.updateItem(board);
		return flag;
	}
	
	@RequestMapping(value="/all", method = RequestMethod.GET)
	public ArrayList<BoardVO> readAll() {
		ArrayList<BoardVO> list = (ArrayList<BoardVO>)boardService.getBoardList();
		return list;
	}
}
