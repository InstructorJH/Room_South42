package bitedu.lesson.simple.vo;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component("memebrVO")
public class MemberVO {
	private String id;
	private String pwd;
	private String name;
	private String email;
	private Timestamp registDate;
	//생성자
	
	public MemberVO() {}
	
	public MemberVO(String id, String pwd, String name, String email, Timestamp registDate) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.email = email;
		this.registDate = registDate;
	}
	
	//getter/setter
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Timestamp getRegistDate() {
		return registDate;
	}
	public void setRegistDate(Timestamp registDate) {
		this.registDate = registDate;
	}

	//toString
	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", pwd=" + pwd + ", name=" + name + ", email=" + email + ", registDate="
				+ registDate + "]";
	}
	
}
