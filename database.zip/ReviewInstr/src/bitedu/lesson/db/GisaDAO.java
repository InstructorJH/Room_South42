package bitedu.lesson.db;

import java.sql.Connection;

public class GisaDAO {
	
	public void testDatabase() {
		Connection con = ConnectionManager.getConnection();
		if(con!=null) {
			System.out.println("connect "+con);
			ConnectionManager.closeConnection(null, null, con);
		} else {
			System.out.println("fails");
		}
	}
}
