package bitedu.lesson.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class GisaDAO {
	
	public void testDatabase() {
		Connection con = ConnectionManager.getConnection();
		if(con!=null) {
			System.out.println("connect "+con);
			ConnectionManager.closeConnection(null, null, con);
		} else {
			System.out.println("fails");
		}
	}

	public boolean insertData(ArrayList<StudentVO> list) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into gisaTBL values (?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, 0);
		pstmt.setString(2, "");
		pstmt.setInt(3, 0);
		pstmt.setInt(4, 0);
		pstmt.setInt(5, 0);
		pstmt.setInt(6, 0);
		pstmt.setInt(7, 0);
		pstmt.setInt(8, 0);
		pstmt.setString(9, "");
		pstmt.setString(10, "");
		pstmt.setString(11, "");
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}
}










