package bitedu.lesson.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class GisaDAO {
	
	public void testDatabase() {
		Connection con = ConnectionManager.getConnection();
		if(con!=null) {
			System.out.println("connect "+con);
			ConnectionManager.closeConnection(null, null, con);
		} else {
			System.out.println("fails");
		}
	}

	public int selectQuiz1(String sql) throws SQLException {
		int result = 0;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
			result = rs.getInt(1);
		}
		ConnectionManager.closeConnection(rs, stmt, con);
		return result;
	}
	
	public boolean insertData(ArrayList<StudentVO> list) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into gisaTBL values (?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		int affectedCount = 0;
		for(StudentVO vo : list) {
			pstmt.setInt(1, vo.getStdno());
			pstmt.setString(2, vo.getEmail());
			pstmt.setInt(3, vo.getKor());
			pstmt.setInt(4, vo.getEng());
			pstmt.setInt(5, vo.getMath());
			pstmt.setInt(6, vo.getSci());
			pstmt.setInt(7, vo.getHist());
			pstmt.setInt(8, vo.getTotal());
			pstmt.setString(9, vo.getMgrCode());
			pstmt.setString(10, vo.getAccCode());
			pstmt.setString(11, vo.getLocCode());
			affectedCount = pstmt.executeUpdate();
		}
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}
}










