package bitedu.lesson.db;

import java.sql.SQLException;
import java.util.ArrayList;

public class Solution {

	public void storeData(ArrayList<StudentVO> list) {
		GisaDAO dao = new GisaDAO();
		boolean flag = false;
		try {
			flag = dao.insertData(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag) {
			System.out.println("입력완료");
		} else {
			System.out.println("입력실패");
		}
	}
	
}
