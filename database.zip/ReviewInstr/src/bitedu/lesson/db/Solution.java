package bitedu.lesson.db;

import java.sql.SQLException;
import java.util.ArrayList;

public class Solution {

	public void storeData(ArrayList<StudentVO> list) {
		GisaDAO dao = new GisaDAO();
		boolean flag = false;
		try {
			flag = dao.insertData(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag) {
			System.out.println("입력완료");
		} else {
			System.out.println("입력실패");
		}
	}
	
	public int solveQuiz1() {
		int result = 0;
		//query 작성
		String sql = "select max(kor+eng) from gisaTBL where loc_code = 'B'";
		GisaDAO dao = new GisaDAO();
		try {
			result = dao.selectQuiz1(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
}
