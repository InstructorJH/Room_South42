package bitedu.lesson.db;

public class TestCenter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestCenter center = new TestCenter();
		center.testDB();
	}
	
	public void testDB() {
		GisaDAO dao = new GisaDAO();
		dao.testDatabase();
	}

}
