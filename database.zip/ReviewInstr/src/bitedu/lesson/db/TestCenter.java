package bitedu.lesson.db;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TestCenter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestCenter center = new TestCenter();
		//center.testDB();
		center.startTest();
	}
	
	public void testDB() {
		GisaDAO dao = new GisaDAO();
		dao.testDatabase();
	}
	
	public ArrayList<StudentVO> readyData() throws NumberFormatException, IOException {
		ArrayList<StudentVO> list = null;
		File file = new File("./data/Abc1115.csv");
		//System.out.println(file.exists());
		//한줄씩 읽어 들여서 VO객체 생성
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line = null;
		list = new ArrayList<StudentVO>();
		StudentVO vo = null;
		while ((line=br.readLine())!=null) {
			String[] temp = line.split(",");
			int stdno = Integer.parseInt(temp[0]);
			String email = temp[1];
			int kor = Integer.parseInt(temp[2].trim());
			int eng = Integer.parseInt(temp[3].trim());
			int math = Integer.parseInt(temp[4].trim());
			int sci = Integer.parseInt(temp[5].trim());
			int hist = Integer.parseInt(temp[6].trim());
			int total = Integer.parseInt(temp[7].trim());
			String mgrCode = temp[8];
			String accCode = temp[9];
			String locCode = temp[10];
			vo = new StudentVO(stdno, email, kor, eng, math, sci, hist, total, mgrCode, accCode, locCode);
			list.add(vo);
			//System.out.println(line);
		}
		br.close();
		fr.close();
		return list;
	}
	
	public void startTest() {
		//데이터 작업 준비 -->DB입력
//		ArrayList<StudentVO> list = null;
//		try {
//			list = this.readyData();
//		} catch (NumberFormatException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Solution solution = new Solution();
//		solution.storeData(list);
		//4개의 문제 풀고
		int answer = solution.solveQuiz1();
		System.out.println(answer);
		//정답을 제공받아 파일에 저장
	}
	
	

}
