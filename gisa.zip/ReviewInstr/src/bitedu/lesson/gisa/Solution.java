package bitedu.lesson.gisa;

import java.util.ArrayList;

public class Solution {
	private ArrayList<StudentVO> list;
	
	public Solution(ArrayList<StudentVO> list) {
		this.list = list;
	}
	
	public int solveQuiz1() {
		int result = 0;
		
		return result;
	}
	
	public int solveQuiz2() {
		int result = 0;
		
		return result;
	}
	
	public int solveQuiz3() {
		int result = 0;
		
		return result;
	}
	
	public int solveQuiz4() {
		int result = 0;
		
		return result;
	}
	
	
}
