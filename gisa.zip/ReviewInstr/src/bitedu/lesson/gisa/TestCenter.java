package bitedu.lesson.gisa;

public class TestCenter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// startTest 호출
	}
	
	public void startTest() {
		//파일을 읽어서 1000개의 VO객체를 갖는 리스트 생성
		
		//리스트를 Solution에 전달
		
		//차례로 1~4번까지 문제푸는 메소드 호출.
		
		//4개의 답을 차례로 각각의 파일에 저장.		
	}

}
