package bitedu.lesson.gisa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TestCenter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// startTest 호출
		TestCenter center = new TestCenter();
		center.startTest();
	}
	
	public void startTest() {
		//파일을 읽어서 1000개의 VO객체를 갖는 리스트 생성
		ArrayList<StudentVO> list = null;
		try {
			list = this.makeData();
			//this.printCheckList(list);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//리스트를 Solution에 전달
		Solution solution = new Solution(list);
		//차례로 1~4번까지 문제푸는 메소드 호출.
		int[] answers = new int[4];
		answers[0] = solution.solveQuiz1();
		answers[1] = solution.solveQuiz2();
		answers[2] = solution.solveQuiz3();
		answers[3] = solution.solveQuiz4();
		//4개의 답을 차례로 각각의 파일에 저장.	
		this.submitAnswers(answers);
	}
	
	private void printCheckList(ArrayList<StudentVO> list) {
		// TODO Auto-generated method stub
		for(StudentVO vo : list) {
			System.out.println(vo);
		}
	}

	private void submitAnswers(int[] answers) {
		// TODO Auto-generated method stub
		
	}

	private ArrayList<StudentVO> makeData() throws IOException{
		ArrayList<StudentVO> list = null;
		File file = new File("./data/Abc1115.csv");
		//System.out.println(file.exists());
		//한줄씩 읽어 들여서 VO객체 생성
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line = null;
		list = new ArrayList<StudentVO>();
		StudentVO vo = null;
		while ((line=br.readLine())!=null) {
			String[] temp = line.split(",");
			int stdno = Integer.parseInt(temp[0]);
			String email = temp[1];
			int kor = Integer.parseInt(temp[2].trim());
			int eng = Integer.parseInt(temp[3].trim());
			int math = Integer.parseInt(temp[4].trim());
			int sci = Integer.parseInt(temp[5].trim());
			int hist = Integer.parseInt(temp[6].trim());
			int total = Integer.parseInt(temp[7].trim());
			String mgrCode = temp[8];
			String accCode = temp[9];
			String locCode = temp[10];
			vo = new StudentVO(stdno, email, kor, eng, math, sci, hist, total, mgrCode, accCode, locCode);
			list.add(vo);
			//System.out.println(line);
		}
		br.close();
		fr.close();
		return list;
	}

}











