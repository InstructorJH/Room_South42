package bitedu.lesson.review;
import java.util.Random;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t = new Test();
		t.testRandom();
	}
	
	public void testRandom() {
		int[] numbers = new int[6];
		// 임의의 수를 추출하기 위해서 Random 클래스 이용
		// 클래스를 이용해서 코딩
		// 1. 객체 생성 2. 변수 할당  3. 필요한 메소드 호출(1~45사이의 수 중) 
		Random rnd = new Random();
		for(int i=0;i<6;i++) {
			int number = rnd.nextInt(45)+1; // 0~44까지의 임의수 추출
			// 생성한 수가 그전에 삽입된 숫자들과 비교해서 
			boolean isSameNumber = false;
			for(int j=0;j<i;j++) {
				if (numbers[j]==number) {
					isSameNumber = true;
					System.out.println("중복발생 "+number);
				}
			}
			// 없으면 할당하는 로직 추가
			if(!isSameNumber) {
				numbers[i] = number;
			} else {
				i--;
			}
		}
		
		for (int i=0;i<6;i++) {
			System.out.println(numbers[i]);
		}
		
//		for (int temp : numbers) {
//			System.out.println(temp);
//		}
		
	}

}
