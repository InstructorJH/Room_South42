package bitedu.lesson.simple.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.lesson.simple.dao.BoardDAO;
import bitedu.lesson.simple.vo.BoardVO;

@Service("boardService")
public class BoardService {
	
	@Autowired
	private BoardDAO boardDAO;
	
	public ArrayList<BoardVO> getBoardList(){
		ArrayList<BoardVO> list = null;
		try {
			list = boardDAO.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public boolean saveItem(BoardVO board) {
		boolean flag = false;
		try {
			flag = boardDAO.insertBoard(board);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	public boolean removeItem(int seq) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = boardDAO.deleteItem(seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	public BoardVO findItem(int seq) {
		// TODO Auto-generated method stub
		BoardVO board = null;
		try {
			board = boardDAO.selectItem(seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return board;
	}
}
