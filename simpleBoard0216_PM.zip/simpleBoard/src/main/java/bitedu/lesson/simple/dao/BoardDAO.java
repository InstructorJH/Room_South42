package bitedu.lesson.simple.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import bitedu.lesson.simple.utils.ConnectionManager;
import bitedu.lesson.simple.vo.BoardVO;

@Repository
public class BoardDAO {
	public ArrayList<BoardVO> findAll() throws SQLException{
		ArrayList<BoardVO> list = null;
		list = new ArrayList<BoardVO>();
		Connection con = ConnectionManager.getConnection();
		//System.out.println(con);
		String sql = "select * from simple_board";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		BoardVO board = null;
		while(rs.next()) {
			int seq = rs.getInt(1);
			String title = rs.getString(2);
			String content = rs.getString(3);
			String writer = rs.getString(4);
			int readCount = rs.getInt(5);
			Timestamp createDate = rs.getTimestamp(6);
			String attatchImg = rs.getString(7);
			String attatchData = rs.getString(8);
			board = new BoardVO(seq, title, content, writer, readCount, createDate, attatchImg, attatchData);
			list.add(board);
		}
		ConnectionManager.closeConnection(rs, stmt, con);
		return list;
	}

	public boolean insertBoard(BoardVO board) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into simple_board(title,content,writer,create_date,attatch_img,attatch_data)"
							+ " values (?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, board.getTitle());
		pstmt.setString(2, board.getContent());
		pstmt.setString(3, board.getWriter());
		pstmt.setTimestamp(4, board.getCreateDate());
		pstmt.setString(5,board.getAttatchImg());
		pstmt.setString(6, board.getAttatchData());
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}

	public boolean deleteItem(int seq) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "delete from simple_board where seq = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, seq);
		int affectedCount = pstmt.executeUpdate();
		if(affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		return flag;
	}

	public BoardVO selectItem(int seq) throws SQLException {
		// TODO Auto-generated method stub
		Connection con = ConnectionManager.getConnection();
		//System.out.println(con);
		String sql = "select * from simple_board where seq = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, seq);
		ResultSet rs = pstmt.executeQuery();
		BoardVO board = null;
		while(rs.next()) {
			int temp = rs.getInt(1);
			String title = rs.getString(2);
			String content = rs.getString(3);
			String writer = rs.getString(4);
			int readCount = rs.getInt(5);
			Timestamp createDate = rs.getTimestamp(6);
			String attatchImg = rs.getString(7);
			String attatchData = rs.getString(8);
			board = new BoardVO(seq, title, content, writer, readCount, createDate, attatchImg, attatchData);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return board;
	}
}
