from django.db import models

# Create your models here.
class Member(models.Model):
    userId = models.CharField(max_length=20)
    userName = models.CharField(max_length=20)
    userPass = models.CharField(max_length=12)
    userEmail = models.CharField(max_length=50)
    registDate = models.DateTimeField(null=True)
    pass