from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Member
from datetime import datetime as dt
from .forms import MemberForm
from django.utils import timezone
# Create your views here.

def index(request):

    return HttpResponse("<h1>Hello~ Django</h1>")


def list(request):
    member_list = Member.objects.order_by('-registDate')
    context = {'member_list':member_list}
    return render(request,'member/list.html',context)

def view_regist(request):
    dateInfo = dt.now().strftime('%Y-%m-%d %H:%M:%S')
    context = {'dateInfo':dateInfo}
    return render(request, 'member/regist.html',context)

def regist(request):
    print('regist process')
    if request.method == 'POST':
        form = MemberForm(request.POST)
        member = form.save(commit=False)
        member.registDate = timezone.now()
        member.save()
        pass
    return redirect('../list')


def detail(request,user_id):
    member = Member.objects.get(userId=user_id)
    context = {'member':member}
    return render(request,'member/detail.html',context)


def delete(request,user_id):
    member = Member.objects.get(userId=user_id)
    member.delete()
    return redirect('../list')


def view_update(request,user_id):
    member = Member.objects.get(userId=user_id)
    context = {'member': member}
    return render(request,'member/update.html',context)

def update(request,user_id):
    member = Member.objects.get(userId=user_id)
    if request.method == 'POST':
        form = MemberForm(request.POST, instance=member)
        member = form.save(commit=False)
        member.save()
    return redirect('../list')










